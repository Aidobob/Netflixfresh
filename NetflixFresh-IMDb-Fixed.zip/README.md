# Netflix Fresh — IMDb Fixed

This package fixes the Compose `Text()` compilation errors in the previous IMDb build.

It contains the IMDb-based app shell, Movies/TV/Docs tabs, poster support, IMDb ratings/IDs, cached feed, Settings, and a 3-day WorkManager refresh hook.

Important: IMDb does not provide a normal consumer login/API key for this use case. A proper live Netflix Ireland feed needs an authorised availability/metadata backend. Keep partner credentials on that server, not inside the APK.

Build: open this ROOT folder in Android Studio, wait for Gradle sync, then Build > Generate App Bundles or APKs > Generate APKs.
