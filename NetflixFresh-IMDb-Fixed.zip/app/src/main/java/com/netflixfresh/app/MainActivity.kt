package com.netflixfresh.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.*
import coil.compose.AsyncImage
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import java.util.concurrent.TimeUnit

data class TitleItem(
    val title:String,val imdbId:String,val type:String,val year:Int,
    val rating:Double,val releaseDate:String,val posterUrl:String?,val justWatchUrl:String?
)
data class FeedResponse(val updatedAt:String,val movies:List<TitleItem>,val tv:List<TitleItem>,val docs:List<TitleItem>)
interface FeedApi { @GET("feed") suspend fun feed(@Header("Authorization") auth:String?=null):FeedResponse }

class MainActivity:ComponentActivity(){
    override fun onCreate(state:Bundle?){
        super.onCreate(state)
        scheduleRefresh(this)
        setContent{MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFFE50914))){App(this)}}
    }
}
fun scheduleRefresh(c:Context){
    val r=PeriodicWorkRequestBuilder<RefreshWorker>(3,TimeUnit.DAYS)
        .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
    WorkManager.getInstance(c).enqueueUniquePeriodicWork("netflix_fresh_3day",ExistingPeriodicWorkPolicy.UPDATE,r)
}
class RefreshWorker(c:Context,p:WorkerParameters):CoroutineWorker(c,p){
    override suspend fun doWork():Result=try{FeedRepository(applicationContext).refresh();Result.success()}catch(_:Exception){Result.retry()}
}
class FeedRepository(private val c:Context){
    private val p=c.getSharedPreferences("netflix_fresh",0);private val gson=Gson()
    suspend fun get():FeedResponse{
        p.getString("feed",null)?.let{return gson.fromJson(it,object:TypeToken<FeedResponse>(){}.type)}
        return demo()
    }
    suspend fun refresh():FeedResponse{
        val u=p.getString("url","").orEmpty()
        if(u.isBlank())return demo()
        val api=Retrofit.Builder().baseUrl(if(u.endsWith("/"))u else "$u/")
            .addConverterFactory(GsonConverterFactory.create()).build().create(FeedApi::class.java)
        val t=p.getString("token","").orEmpty()
        val result=api.feed(if(t.isBlank())null else "Bearer $t")
        p.edit().putString("feed",gson.toJson(result)).apply();return result
    }
    fun save(u:String,t:String){p.edit().putString("url",u.trim()).putString("token",t.trim()).apply()}
    fun settings()=p.getString("url","").orEmpty() to p.getString("token","").orEmpty()
}
fun demo():FeedResponse{
    fun x(i:Int,n:String)=TitleItem(n,"tt00000$i","movie",2026,8.0-i*.1,"2026-09-${(10-i).coerceAtLeast(1)}",null,null)
    return FeedResponse("Demo data — live feed not connected",(1..10).map{x(it,"Demo Movie $it")},
        listOf(x(11,"Demo TV One"),x(12,"Demo TV Two")),listOf(x(13,"Demo Documentary One"),x(14,"Demo Documentary Two")))
}
@Composable fun App(c:Context){
    var tab by remember{mutableIntStateOf(0)};var settings by remember{mutableStateOf(false)}
    var feed by remember{mutableStateOf<FeedResponse?>(null)}
    LaunchedEffect(Unit){feed=FeedRepository(c).get()}
    if(settings){Settings(c,{settings=false},{settings=false;feed=null});return}
    val f=feed?:return
    Scaffold(containerColor=Color(0xFF090909),bottomBar={
        NavigationBar(containerColor=Color(0xFF111111)){
            listOf("Movies","TV","Docs").forEachIndexed{i,n->
                NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(if(i==0)"🎬" else if(i==1)"📺" else "🎞️")},label={Text(n)})
            }
        }
    }){pad->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            item{
                Row(verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Text("NETFLIX FRESH",fontSize=27.sp,fontWeight=FontWeight.Black,color=Color.White)
                        Text("🇮🇪 Ireland • IMDb-powered",color=Color.Gray)
                    }
                    TextButton(onClick={ {settings=true} }){Text("⚙")}
                }
                Spacer(Modifier.height(10.dp))
                Text("Top 10 ${if(tab==0)"Movies" else if(tab==1)"TV Shows" else "Documentaries"}",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Color.White)
                Text(f.updatedAt,fontSize=12.sp,color=Color.Gray)
            }
            val list=if(tab==0)f.movies else if(tab==1)f.tv else f.docs
            items(list.take(10)){CardItem(it)}
        }
    }
}
@Composable fun CardItem(x:TitleItem){
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFF191919)),shape=RoundedCornerShape(14.dp)){
        Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
            Box(Modifier.width(88.dp).height(126.dp).clip(RoundedCornerShape(8.dp)).background(Color.DarkGray),contentAlignment=Alignment.Center){
                if(!x.posterUrl.isNullOrBlank())AsyncImage(model=x.posterUrl,contentDescription=x.title,modifier=Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                else Text("POSTER",color=Color.LightGray)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)){
                Text(x.title,fontSize=18.sp,fontWeight=FontWeight.Bold,color=Color.White)
                Text("${x.year} • IMDb ⭐ ${"%.1f".format(x.rating)}",color=Color.LightGray)
                Text("Released ${x.releaseDate}",fontSize=13.sp,color=Color.Gray)
                Text(x.imdbId,fontSize=12.sp,color=Color(0xFFFFC107))
            }
        }
    }
}
@Composable fun Settings(c:Context,back:()->Unit,saved:()->Unit){
    val repo=remember{FeedRepository(c)};val old=remember{repo.settings()}
    var url by remember{mutableStateOf(old.first)};var token by remember{mutableStateOf(old.second)}
    Column(Modifier.fillMaxSize().background(Color(0xFF090909)).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        TextButton(onClick=back){Text("← Back")}
        Text("Live IMDb / Netflix data",fontSize=24.sp,fontWeight=FontWeight.Bold,color=Color.White)
        Text("IMDb ratings and IDs are used in the feed. Netflix Ireland availability is supplied by the live server.",color=Color.LightGray)
        OutlinedTextField(value=url,onValueChange={url=it},label={Text("Live feed URL")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        OutlinedTextField(value=token,onValueChange={token=it},label={Text("Feed token (optional)")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth(),singleLine=true)
        Button(onClick={repo.save(url,token);saved()},modifier=Modifier.fillMaxWidth()){Text("Save")}
    }
}
